var crypto = require('crypto')
var qs = require('querystring')
var config = {
    key: 'XXXXXXXXXX',
    salt: 'XXXXXXXXXX',
    url: 'https://testpay.easebuzz.in/pay/secure',

};

var params = {
    txnid: '',
    firstname: '',
    email: '',
    phone: '',
    amount: '',
    productinfo: '',
    surl: '',
    furl: '',
    hash: '',
    udf1: '',
    udf2: '',
    udf3: '',
    udf4: '',
    udf5: '',
    udf6: '',
    udf7: '',
    udf8: '',
    udf9: '',
    udf10: '',
}


function initiatePayment(res, parameters, env) {
    if (env == "live") {
        config.url = 'https://pay.easebuzz.in/pay/secure';
    } 
    params = parameters
    for (var keyname in params) {
        params[keyname] = params[keyname].trim()
    }

    generateHash();

    var hiddenform = "<!DOCTYPE html><html><head></head><body>"
    hiddenform += "<form method='post' name='paywitheasebuzzform' id='paywitheasebuzzcheckout' action='" + config.url + "'>"
    hiddenform += "<input type='hidden' name='key' value='" + config.key + "'>";
    for (var key in params) {
        hiddenform += "<input type='hidden' name='" + key + "' value='" + params[key] + "'>";
    }

    hiddenform += "</form><script type='text/javascript'>" +
        "document.getElementById('paywitheasebuzzcheckout').submit();" +
        "</script>";
    hiddenform += "</body></html>"
    res.writeHead(200, {
        'Content-Length': Buffer.byteLength(hiddenform),
        'Content-Type': 'text/html'
    });
    res.write(hiddenform);
    res.end();
}

function generateHash() {
    var hashstring = config.key + "|" + params.txnid + "|" + params.amount + "|" + params.productinfo + "|" + params.firstname + "|" + params.email +
        "|" + params.udf1 + "|" + params.udf2 + "|" + params.udf3 + "|" + params.udf4 + "|" + params.udf5 + "|" + params.udf6 + "|" + params.udf7 + "|" + params.udf8 + "|" + params.udf9 + "|" + params.udf10;
    hashstring += "|" + config.salt;
    params.hash = crypto.createHash('sha512').update(hashstring).digest("hex");
    console.log(hashstring)
    console.log(params.hash)

}

function checkReverseHash(response) {

    var hashstring = config.key + "|" + params.txnid + "|" + params.amount + "|" + params.productinfo + "|" + params.firstname + "|" + params.email + "||||||||||";
    hashstring += "|" + config.salt;
    var hashstring = config.salt + "|" + response.status + "|" + response.udf10 + "|" + response.udf9 + "|" + response.udf8 + "|" + response.udf7 +
        "|" + response.udf6 + "|" + response.udf5 + "|" + response.udf4 + "|" + response.udf3 + "|" + response.udf2 + "|" + response.udf1 + "|" +
        response.email + "|" + response.firstname + "|" + response.productinfo + "|" + response.amount + "|" + response.txnid + "|" + response.key
    rev_hash = crypto.createHash('sha512').update(hashstring).digest("hex");
    if (rev_hash == response.hash) {
        return true;
    } else {
        return false;
    }

}

function validateResponse(req, callback) {
    var body = ""
    req.on('data', function (data) {
        body += data;
        if (body.length > 1e6) {
            // Destroys connection in case of flooding
            request.connection.destroy();
        }
    });
    req.on('end', function () {
        var post_params = qs.parse(body);
        var error = !checkReverseHash(post_params)
        callback(error, post_params)
    });

}


module.exports = {
    initiatePayment: initiatePayment,
    validateResponse: validateResponse
}
